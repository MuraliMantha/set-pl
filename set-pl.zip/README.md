desktop

main-heading => bold  38-40px serif

sub-heading => semi-bold 28px san-serif

content => medium 16px-20px san-serif


button => color =>  #E67817  #85C324  18-20px

